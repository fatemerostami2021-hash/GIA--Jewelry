'use client';
import Link from 'next/link';
import { useCallback, useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import TypeText from './TypeText';
import { ui } from '@/lib/ui';

const PIECES = {
  necklace: '/media/cutouts/necklace.webp',
  earrings: '/media/cutouts/earrings.webp',
  ring: '/media/cutouts/ring.webp',
  bracelet: '/media/cutouts/bracelet.webp',
};
const MODEL = '/media/cutouts/model.webp';
const TOTAL = 8;

/**
 * JewelStage — pinned, scroll-driven 3D jewellery film.
 * The Three.js scene (lib/jewelStage.js) is lazy-loaded when the section nears the viewport;
 * GSAP ScrollTrigger pins the stage and feeds scroll progress into the scene's master timeline.
 * Reduced-motion / no-WebGL visitors get a static composition instead.
 */
export default function JewelStage({ locale }) {
  const s = ui[locale].stage;
  const root = useRef(null);
  const canvasBox = useRef(null);
  const api = useRef(null);
  const st = useRef(null);
  const [beat, setBeat] = useState(0);
  const [mode, setMode] = useState('pending'); // pending | loading | ready | static
  const [wantScene, setWantScene] = useState(false);

  // decide: static fallback vs. 3D, and lazy-start when near the viewport
  useEffect(() => {
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) { setMode('static'); return; }
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setWantScene(true); io.disconnect(); } }, { rootMargin: '700px' });
    io.observe(root.current);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    if (!wantScene || mode === 'static') return;
    let cancelled = false;
    setMode('loading');
    const mobile = matchMedia('(max-width: 767px), (pointer: coarse)').matches;
    gsap.registerPlugin(ScrollTrigger);
    (async () => {
      const mod = await import('@/lib/jewelStage');
      if (cancelled) return;
      api.current = mod.createJewelStage(canvasBox.current, {
        pieces: PIECES, model: MODEL, mobile,
        onBeat: setBeat,
        onReady: () => {
          if (cancelled) return;
          setMode('ready');
          const len = mobile ? 380 : 620;
          st.current = ScrollTrigger.create({
            trigger: root.current,
            start: 'top top',
            end: `+=${len}%`,
            pin: true,
            anticipatePin: 1,
            invalidateOnRefresh: true,
            onUpdate: (self) => api.current?.setTarget(self.progress),
          });
          ScrollTrigger.refresh();
        },
        onError: () => !cancelled && setMode('static'),
      });
    })().catch(() => !cancelled && setMode('static'));
    return () => {
      cancelled = true;
      st.current?.kill(); st.current = null;
      api.current?.dispose(); api.current = null;
    };
  }, [wantScene]); // eslint-disable-line react-hooks/exhaustive-deps

  const goTo = useCallback((index) => {
    const trig = st.current;
    if (!trig) return;
    const p = (index <= 0 ? 0.0 : index + 0.45) / TOTAL; // land inside the beat, after its entrance
    const y = trig.start + (trig.end - trig.start) * Math.min(p, 0.999);
    window.scrollTo({ top: y, behavior: 'smooth' });
  }, []);

  const beats = s.beats;
  const cur = beats[Math.min(beat, beats.length - 1)];
  const dots = beats.map((b, i) => i);

  // ---------- static fallback ----------
  if (mode === 'static') {
    return (
      <section ref={root} className="relative mx-auto max-w-7xl px-5 py-20" aria-label={s.eyebrow}>
        <p className="mb-3 text-xs font-black tracking-[.35em] text-gold-light rtl:tracking-normal">✦ {s.eyebrow}</p>
        <h2 className="font-display text-4xl font-black md:text-6xl"><span className="hl">{beats[5].title}</span></h2>
        <p className="mt-4 max-w-xl text-lg font-bold leading-8 text-lilac/85">{beats[5].text}</p>
        <div className="mt-10 grid items-center gap-8 md:grid-cols-2">
          <img src={MODEL} alt="" className="mx-auto w-full max-w-md rounded-2xl border border-gold/40" loading="lazy" />
          <div className="grid grid-cols-2 gap-6">
            {Object.entries(PIECES).map(([k, src]) => (
              <figure key={k} className="rounded-2xl border border-gold/25 bg-black/30 p-4 text-center">
                <img src={src} alt={beats[Object.keys(PIECES).indexOf(k) + 1].title} className="mx-auto h-36 object-contain" loading="lazy" />
                <figcaption className="mt-2 text-sm font-black text-gold-light">{beats[Object.keys(PIECES).indexOf(k) + 1].title}</figcaption>
              </figure>
            ))}
          </div>
        </div>
        <div className="mt-8 flex flex-wrap gap-4">
          <Link href={`/${locale}/collection`} className="rounded-full bg-gold px-8 py-3 text-sm font-black text-ink hover:bg-gold-light">{s.cta}</Link>
          <Link href={`/${locale}/gemstones`} className="rounded-full border-2 border-gold px-8 py-3 text-sm font-black text-gold-light hover:bg-gold/15">{s.cta2}</Link>
        </div>
      </section>
    );
  }

  const btn = 'stage-chip grid h-10 w-10 place-items-center rounded-full border border-gold/50 bg-ink/70 text-lg font-black text-gold-light backdrop-blur hover:bg-gold/20 focus-visible:outline focus-visible:outline-2 focus-visible:outline-gold';

  return (
    <section ref={root} className="stage-vignette relative h-screen min-h-[600px] w-full overflow-hidden" aria-label={s.eyebrow}>
      {/* poster while the scene loads */}
      <div className={`absolute inset-0 grid place-items-center transition-opacity duration-700 ${mode === 'ready' ? 'pointer-events-none opacity-0' : 'opacity-100'}`}>
        <img src={MODEL} alt="" className="absolute inset-0 h-full w-full object-cover opacity-15 blur-md" />
        <p className="relative text-sm font-black text-gold-light"><span className="twinkle">✦</span> {s.loading}</p>
      </div>

      <div ref={canvasBox} className="absolute inset-0" aria-hidden />

      {/* caption */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 px-6 pb-28 md:inset-y-0 md:end-auto md:flex md:w-[46%] md:flex-col md:justify-center md:px-14 md:pb-0 lg:px-20">
        <p className="mb-3 text-xs font-black tracking-[.35em] text-gold-light rtl:tracking-normal">✦ {s.eyebrow}</p>
        <h2 className="stage-title min-h-[1.2em] font-display text-3xl font-black text-lilac md:text-6xl">
          <TypeText text={cur.title} once speed={48} />
        </h2>
        <p key={cur.k} className="cap-in mt-4 max-w-md text-base font-bold leading-8 text-lilac/90 md:text-lg" style={{ animation: 'captionIn .8s cubic-bezier(.2,.8,.2,1) both' }}>{cur.text}</p>
        {beat === beats.length - 1 && (
          <div className="pointer-events-auto mt-6 flex flex-wrap gap-3">
            <Link href={`/${locale}/collection`} className="rounded-full bg-gold px-7 py-3 text-sm font-black text-ink transition-all hover:bg-gold-light hover:shadow-[0_0_30px_rgba(242,217,138,.55)]">{s.cta}</Link>
            <Link href={`/${locale}/gemstones`} className="rounded-full border-2 border-gold px-7 py-3 text-sm font-black text-gold-light hover:bg-gold/15">{s.cta2}</Link>
          </div>
        )}
      </div>

      {/* piece switcher (jump between beats) */}
      <nav className="absolute inset-x-0 bottom-5 z-20 flex flex-wrap items-center justify-center gap-2 px-3" aria-label={s.eyebrow}>
        {dots.map((i) => (
          <button
            key={i}
            type="button"
            onClick={() => goTo(i)}
            aria-current={beat === i}
            className={`stage-chip rounded-full border px-3.5 py-1.5 text-xs font-black backdrop-blur ${beat === i ? 'border-gold bg-gold text-ink' : 'border-gold/40 bg-ink/60 text-lilac/85 hover:border-gold hover:text-gold-light'}`}
          >
            {beats[i].title.length > 16 && i > 0 && i < 5 ? beats[i].title.split(' ').slice(-1)[0] : beats[i].title}
          </button>
        ))}
      </nav>

      {/* camera controls */}
      <div className="absolute end-4 top-28 z-20 flex flex-col gap-2 md:top-32">
        <button type="button" className={btn} onClick={() => api.current?.zoom(1.2)} aria-label={s.zoomIn}>+</button>
        <button type="button" className={btn} onClick={() => api.current?.zoom(1 / 1.2)} aria-label={s.zoomOut}>−</button>
        <button type="button" className={btn} onClick={() => api.current?.resetView()} aria-label={s.reset} title={s.reset}>⟲</button>
        <button type="button" className={btn} onClick={() => document.getElementById('home-collection')?.scrollIntoView({ behavior: 'smooth' })} aria-label={s.skip} title={s.skip}>⇣</button>
      </div>

      {/* hints */}
      <p className="pointer-events-none absolute start-5 top-28 z-10 hidden text-xs font-bold text-lilac/55 md:top-32 md:block">
        {beat === 0 ? s.scroll : beat < 5 ? s.drag : ''}
      </p>
    </section>
  );
}
