'use client';
import Link from 'next/link';
import { useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, EffectFade, Navigation, Pagination, Keyboard } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/effect-fade';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import TypeText from './TypeText';

const DELAY = 4800;

/**
 * HeroSlider — shows each photograph COMPLETE.
 *   - The picture is `object-contain` inside a 16:9-ish stage, so nothing is cropped or zoomed.
 *   - A blurred, darkened copy of the same photo fills the rest of the stage (no empty bars).
 *   - Captions animate in on every slide (staggered), the title is typed, and a progress line
 *     shows when the next slide arrives. Arrows, dots, keyboard and swipe all work.
 */
export default function HeroSlider({ slides = [], labels = {}, locale = 'en' }) {
  const [active, setActive] = useState(0);
  if (!slides.length) return null;
  return (
    <section className="relative w-full" aria-roledescription="carousel" aria-label="Featured pieces">
      <Swiper
        modules={[Autoplay, EffectFade, Navigation, Pagination, Keyboard]}
        effect="fade"
        fadeEffect={{ crossFade: true }}
        autoplay={{ delay: DELAY, disableOnInteraction: false, pauseOnMouseEnter: true }}
        loop
        speed={900}
        keyboard
        navigation
        pagination={{ clickable: true }}
        onSlideChange={(s) => setActive(s.realIndex)}
        dir={locale === 'fa' ? 'rtl' : 'ltr'}
        className="gia-slider"
      >
        {slides.map((s, i) => (
          <SwiperSlide key={i}>
            <div className="relative h-[68vh] min-h-[420px] w-full overflow-hidden md:h-[78vh] md:max-h-[820px]">
              {/* blurred backdrop built from the same image */}
              <img src={s.src} alt="" aria-hidden className="slide-bg absolute inset-0 h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-b from-ink/40 via-transparent to-ink/80" />
              {/* the complete, un-cropped photo */}
              <Link href={s.href} className="absolute inset-0 flex items-center justify-center px-4 pb-24 pt-6 md:px-20 md:pb-10" aria-label={s.alt}>
                <img
                  src={s.src}
                  alt={s.alt}
                  loading={i === 0 ? 'eager' : 'lazy'}
                  className="max-h-full max-w-full rounded-xl border border-gold/30 object-contain shadow-[0_20px_80px_rgba(0,0,0,.65)]"
                />
              </Link>
              {/* caption */}
              <div className="pointer-events-none absolute inset-x-0 bottom-0 flex flex-col items-start gap-2 bg-gradient-to-t from-ink via-ink/70 to-transparent px-6 pb-10 pt-24 md:px-20">
                <p className="cap-in text-xs font-black tracking-[.35em] text-gold-light rtl:tracking-normal">✦ {s.eyebrow}</p>
                <h3 className="cap-in d2 font-display text-2xl font-black text-lilac md:text-5xl">
                  {i === active ? <TypeText text={s.alt} once speed={42} /> : s.alt}
                </h3>
                <p className="cap-in d3 text-sm font-bold text-gold-light/90 md:text-base">
                  {labels.view} · {String(i + 1).padStart(2, '0')} {labels.of} {String(slides.length).padStart(2, '0')}
                </p>
              </div>
              {i === active && <span key={`p${active}`} className="slide-progress absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-gold via-gold-light to-gold" style={{ '--dur': `${DELAY}ms` }} />}
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </section>
  );
}
