'use client';
import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

const IMG = '/media/images/optimized/ruby-scroll-companion.webp';

/**
 * ScrollCompanion — a small framed window fixed to one side of the page. While the visitor
 * scrolls from the hero to the footer, it travels down the side of the screen and pans across
 * the ruby showcase picture (jewellery spiral first, the model last), with a gold progress ring
 * and a slight 3D tilt. Fast scrolling is smoothed (scrub). Reduced motion: static, bottom corner.
 */
export default function ScrollCompanion({ href, label }) {
  const box = useRef(null);
  const img = useRef(null);
  const ring = useRef(null);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    const el = box.current;
    if (!el || hidden) return;
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce) { gsap.set(el, { y: 0 }); return; }
    gsap.registerPlugin(ScrollTrigger);
    const R = 46, C = 2 * Math.PI * R;
    const ctx = gsap.context(() => {
      gsap.set(ring.current, { strokeDasharray: C, strokeDashoffset: C });
      const travel = () => Math.max(0, window.innerHeight - el.offsetHeight - 120 - 24);
      gsap.fromTo(el, { y: 0, opacity: 0 }, { opacity: 1, duration: 0.8, delay: 1.2 });
      const tl = gsap.timeline({
        defaults: { ease: 'none' },
        scrollTrigger: { trigger: document.documentElement, start: 'top top', end: 'bottom bottom', scrub: 0.5, invalidateOnRefresh: true },
      });
      tl.to(el, { y: () => travel(), rotateY: -14, duration: 1 }, 0)
        .fromTo(img.current, { objectPosition: '0% 50%', scale: 1.05 }, { objectPosition: '100% 50%', scale: 1.15, duration: 1 }, 0)
        .to(ring.current, { strokeDashoffset: 0, duration: 1 }, 0);
    });
    return () => ctx.revert();
  }, [hidden]);

  if (hidden) return null;
  return (
    <div
      ref={box}
      className="pointer-events-none fixed start-3 top-[120px] z-40 hidden opacity-0 sm:block md:start-5 [perspective:700px]"
      style={{ opacity: 0 }}
    >
      <div className="pointer-events-auto relative h-[190px] w-[120px] md:h-[230px] md:w-[148px]">
        <Link
          href={href}
          aria-label={label}
          className="absolute inset-0 block overflow-hidden rounded-[1.4rem] border-2 border-gold/70 shadow-[0_12px_40px_rgba(0,0,0,.6),0_0_28px_rgba(212,175,55,.35)] transition-transform duration-300 hover:scale-105"
        >
          <img ref={img} src={IMG} alt="" className="h-full w-full object-cover" loading="lazy" />
          <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/60 via-transparent to-transparent" />
        </Link>
        <svg viewBox="0 0 100 100" className="pointer-events-none absolute -end-3 -top-3 h-12 w-12 -rotate-90" aria-hidden>
          <circle cx="50" cy="50" r="46" fill="rgba(10,6,16,.8)" stroke="rgba(212,175,55,.25)" strokeWidth="6" />
          <circle ref={ring} cx="50" cy="50" r="46" fill="none" stroke="#f2d98a" strokeWidth="6" strokeLinecap="round" />
        </svg>
        <button
          type="button"
          onClick={() => setHidden(true)}
          aria-label="Close"
          className="absolute -start-2 -top-2 grid h-6 w-6 place-items-center rounded-full border border-gold/60 bg-ink text-xs font-black text-gold-light hover:bg-gold hover:text-ink"
        >
          ✕
        </button>
      </div>
    </div>
  );
}
